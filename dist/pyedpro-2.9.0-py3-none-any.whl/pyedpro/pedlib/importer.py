#!/usr/bin/env python

# Im porter for the library

from __future__ import absolute_import

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk
from gi.repository import Gdk
from gi.repository import GObject

# Import all library files as ... so lib dir falls away


# EOF

