#!/usr/bin/env python
 
import sys, os, re, time
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk
from gi.repository import Gdk
from gi.repository import GLib
from gi.repository import GObject
from gi.repository import GdkPixbuf

#import pygtk, gobject, gtk, pango


