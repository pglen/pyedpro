#!/bin/bash
# Install prerequisites for python pyedit pro
sudo apt install python                      
sudo apt install python-gi
sudo apt install python-gi-cairo


